class OutputParserError(ValueError):
    pass
